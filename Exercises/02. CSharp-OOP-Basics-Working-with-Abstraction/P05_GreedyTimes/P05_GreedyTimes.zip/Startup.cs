﻿namespace P05_GreedyTimes
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Startup
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Start();
        }
    }
}