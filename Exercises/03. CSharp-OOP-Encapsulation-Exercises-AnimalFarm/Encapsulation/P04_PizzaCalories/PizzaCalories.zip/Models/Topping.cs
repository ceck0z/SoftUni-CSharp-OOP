﻿namespace P04_PizzaCalories.Models
{
    using P04_PizzaCalories.Exceptions;
    using System;

    public class Topping
    {

        private const double MinWeight = 1;
        private const double MaxWeight = 50;

        private const double Meat = 1.2;
        private const double Veggies = 0.8;
        private const double Cheese = 1.1;
        private const double Sauce = 0.9;

        private double weight;
        private string name;

        public Topping(string name, double weight)
        {
            this.Name = name;
            this.Weight = weight;
        }

        public string Name
        {
            get
            {
                return this.name;
            }
            private set
            {
                if(value.ToLower() != "meat" && value.ToLower() != "veggies" && value.ToLower() != "cheese" && value.ToLower() != "sauce")
                {
                    throw new ArgumentException(string.Format(ExceptionMessages.InvalidToppingNameException,value));
                }
                this.name = value;
            }
        }

        public double Weight
        {
            get
            {
                return this.weight;
            }
            private set
            {
                if( value > MaxWeight || value < MinWeight)
                {
                    throw new ArgumentException(string.Format(ExceptionMessages.InvalidToppingWeightException,name,MinWeight,MaxWeight));
                }

                this.weight = value;
            }
        }

        public double CalculateCalories()
        {
            double calories = 0;

            switch (name.ToLower())
            {
                case "meat": calories = 2 * this.Weight * Meat;
                    break;
                case "veggies": calories = 2 * this.Weight * Veggies;
                    break;
                case "cheese": calories = 2 * this.Weight * Cheese;
                    break;
                case "sauce": calories = 2 * this.Weight * Sauce;
                    break;                   
                default:
                    break;
            }

            return calories;
        }
    }
}
