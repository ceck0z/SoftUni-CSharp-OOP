﻿namespace Zoo
{
    public class Animal
    {
        public Animal(string name)
        {
            this.name = name;
        }

        public string name;

    }
}
