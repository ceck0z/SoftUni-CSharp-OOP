﻿namespace P05_FootballTeamGenerator
{
    public class Startup
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
