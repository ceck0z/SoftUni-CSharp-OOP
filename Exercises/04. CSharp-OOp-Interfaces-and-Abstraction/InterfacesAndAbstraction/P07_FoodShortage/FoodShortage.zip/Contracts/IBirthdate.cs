﻿namespace P07_FoodShortage.Contracts
{
    using System;

    public interface IBirthdate
    {
        DateTime Birthdate { get; }
    }
}
