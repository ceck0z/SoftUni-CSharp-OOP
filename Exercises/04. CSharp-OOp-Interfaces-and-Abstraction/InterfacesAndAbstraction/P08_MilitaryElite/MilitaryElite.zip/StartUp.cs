﻿namespace P08_MilitaryElite
{
    using P08_MilitaryElite.Core;

    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
