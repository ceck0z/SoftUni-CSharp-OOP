﻿namespace P08_MilitaryElite.Enumerations
{
    public enum State
    {
        inProgress,
        Finished
    }
}
