﻿namespace P08_MilitaryElite.Enumerations
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
